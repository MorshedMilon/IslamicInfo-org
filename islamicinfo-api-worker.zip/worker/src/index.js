/* ═══════════════════════════════════════════════════════════════════
   IslamicInfo.org — API Proxy Worker  (v1.0 · Step 4)
   Serves the /api/* contract defined in src/js/api.js.

   LIVE in this version:
     GET /api/verse                      → alquran.cloud (daily, UTC bust)
     GET /api/prayer?city=&date=&method= → api.aladhan.com (24 h cache)

   ROUTED but pending (return 501 with a clear message):
     /api/geocode · /api/quran/[n] · /api/hadith · /api/nisab
     /api/verify · /api/ask-claude · /api/subscribe

   Caching: Cloudflare Cache API at the edge. Browsers also cache via
   Cache-Control (api.js additionally caches in localStorage).

   CORS: locked to the origins in ALLOWED_ORIGINS.
   ═══════════════════════════════════════════════════════════════════ */

const ALLOWED_ORIGINS = [
  'https://islamicinfo.org',
  'https://www.islamicinfo.org',
  'https://morshedmilon.github.io',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
];

/* ─── CORS helpers ─────────────────────────────────────────────────── */
function corsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
  };
}

function json(data, origin, { status = 200, maxAge = 0 } = {}) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    ...corsHeaders(origin),
  };
  if (maxAge > 0) headers['Cache-Control'] = `public, max-age=${maxAge}, s-maxage=${maxAge}`;
  return new Response(JSON.stringify(data), { status, headers });
}

function err(message, origin, status = 502) {
  return json({ error: message }, origin, { status });
}

/* ─── Upstream fetch with timeout ──────────────────────────────────── */
async function upstream(url, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'IslamicInfo.org proxy (hello@islamicinfo.org)' },
    });
    if (!res.ok) throw new Error(`upstream HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

/* ─── UTC date helpers ─────────────────────────────────────────────── */
function todayUTC() {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}
function secondsUntilUTCMidnight() {
  const now = new Date();
  const mid = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  return Math.max(60, Math.floor((mid - now) / 1000));
}

/* ═══════════════════════════════════════════════════════════════════
   GET /api/verse — Verse of the Day
   Contract: { surahName, surahNumber, ayahNumber, arabic,
               translation, translator, reference }
   Deterministic daily pick across all 6,236 ayahs; same verse for
   every visitor worldwide until UTC midnight.
   ═══════════════════════════════════════════════════════════════════ */
export async function handleVerse(origin) {
  const epochDay = Math.floor(Date.now() / 86400000);
  const ayahGlobal = (epochDay % 6236) + 1; // 1..6236

  const data = await upstream(
    `https://api.alquran.cloud/v1/ayah/${ayahGlobal}/editions/quran-uthmani,en.sahih`
  );
  const ar = data?.data?.[0];
  const en = data?.data?.[1];
  if (!ar || !en) throw new Error('verse: unexpected upstream shape');

  const body = {
    surahName: ar.surah.englishName,
    surahNumber: ar.surah.number,
    ayahNumber: ar.numberInSurah,
    arabic: ar.text,
    translation: en.text,
    translator: 'Saheeh International',
    reference: `${ar.surah.englishName} ${ar.surah.number}:${ar.numberInSurah}`,
    date: todayUTC(),
    source: 'api.alquran.cloud',
  };
  return json(body, origin, { maxAge: secondsUntilUTCMidnight() });
}

/* ═══════════════════════════════════════════════════════════════════
   GET /api/prayer?city=&date=&method=
   Contract: { city, date, method,
               timings: { Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha },
               source }
   date in = YYYY-MM-DD (api.js) → AlAdhan wants DD-MM-YYYY.
   method default 3 (Muslim World League), matching the frontend.
   ═══════════════════════════════════════════════════════════════════ */
export async function handlePrayer(searchParams, origin) {
  const city = (searchParams.get('city') || '').trim();
  if (!city) return err('missing required parameter: city', origin, 400);
  if (city.length > 80) return err('city parameter too long', origin, 400);

  const dateIn = searchParams.get('date') || todayUTC();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateIn)) return err('date must be YYYY-MM-DD', origin, 400);
  const [y, m, d] = dateIn.split('-');

  const method = String(parseInt(searchParams.get('method') || '3', 10) || 3);

  const data = await upstream(
    `https://api.aladhan.com/v1/timingsByCity/${d}-${m}-${y}` +
    `?city=${encodeURIComponent(city)}&method=${method}`
  );
  const t = data?.data?.timings;
  if (!t) throw new Error('prayer: unexpected upstream shape');

  const clean = (s) => (s || '').split(' ')[0]; // strip timezone suffixes like "(BST)"
  const body = {
    city,
    date: dateIn,
    method: Number(method),
    timings: {
      Fajr: clean(t.Fajr),
      Sunrise: clean(t.Sunrise),
      Dhuhr: clean(t.Dhuhr),
      Asr: clean(t.Asr),
      Maghrib: clean(t.Maghrib),
      Isha: clean(t.Isha),
    },
    hijri: data?.data?.date?.hijri
      ? `${data.data.date.hijri.day} ${data.data.date.hijri.month?.en} ${data.data.date.hijri.year} AH`
      : undefined,
    source: 'api.aladhan.com',
  };
  return json(body, origin, { maxAge: 6 * 3600 }); // 6 h edge cache
}

/* ═══════════════════════════════════════════════════════════════════
   Router
   ═══════════════════════════════════════════════════════════════════ */
const PENDING = ['/api/geocode', '/api/hadith', '/api/nisab',
                 '/api/verify', '/api/ask-claude', '/api/subscribe'];

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '';
    const path = url.pathname.replace(/\/+$/, '') || '/';

    /* CORS preflight */
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }

    try {
      /* Edge cache for GETs */
      if (request.method === 'GET') {
        const cache = caches.default;
        const hit = await cache.match(request);
        if (hit) {
          const res = new Response(hit.body, hit);
          // Re-stamp CORS for this caller's origin
          Object.entries(corsHeaders(origin)).forEach(([k, v]) => res.headers.set(k, v));
          return res;
        }

        let res = null;
        if (path === '/api/verse') res = await handleVerse(origin);
        else if (path === '/api/prayer') res = await handlePrayer(url.searchParams, origin);

        if (res) {
          if (res.status === 200) await cache.put(request, res.clone());
          return res;
        }
      }

      if (path.startsWith('/api/quran/') || PENDING.includes(path)) {
        return err(`endpoint ${path} is scheduled in a later roadmap step`, origin, 501);
      }

      if (path === '/' || path === '/api') {
        return json({
          service: 'IslamicInfo.org API proxy',
          live: ['/api/verse', '/api/prayer'],
          pending: PENDING.concat('/api/quran/[surah]'),
        }, origin);
      }

      return err('not found', origin, 404);
    } catch (e) {
      return err(`upstream failure: ${e.message}`, origin, 502);
    }
  },
};
